$(document).ready(function(){
    $(".owl-carousel").owlCarousel({

    autoplay: true,
    loop: true,
    items: 7,
    margin: 10,

    });

});