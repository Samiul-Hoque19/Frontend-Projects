$(document).ready(function(){

    $(".owl-carousel").owlCarousel({

      autoplay: true,
      items: 3,
      loop: true,
      autoplaySpeed: 5000,
    });

    AOS.init();

  });