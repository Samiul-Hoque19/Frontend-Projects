$(document).ready(function(){

    $(".owl-carousel").owlCarousel({

      autoplay: true,
      items: 4,
      loop: true,
      autoplaySpeed: 7000,

      responsiveClass:true,

      responsive:{
          0:{
              items:1,
              margin:25,
              loop:true,
              nav:true,
              gap:20,
          },
          600:{
              items:1,
              loop:true,
              nav:true,
              margin:25,
              gap:20,
          },
          650:{
              items:4,
              loop:true,
              margin:25,
              nav:true,
              gap:20,
          }
      }
    });
  });