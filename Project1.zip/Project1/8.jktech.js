$(document).ready(function(){

    $(".owl-carousel").owlCarousel({

    autoplay: true,
    loop: true,
    items: 3,
    margin: 230,

    responsiveClass:true,

    responsive:{
        0:{
            items:1,
            nav:true,
        },
        50:{
            items:1,
            nav:false,
        },
        550:{
            items:3,
            nav:true,
            loop:true,
        }
    }

    });

});