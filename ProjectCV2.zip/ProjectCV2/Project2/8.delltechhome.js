$(document).ready(function(){

    $(".owl-carousel").owlCarousel({

      autoplay: true,
      items: 1,
      loop: true,
    });
    
  });
function toggleMobileMenu(menu)
{
  menu.classList('open');
}