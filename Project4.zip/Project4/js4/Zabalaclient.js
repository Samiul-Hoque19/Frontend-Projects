$(document).ready(function(){
         
    $(".owl-carousel").owlCarousel({

      autoplay: true,
      items: 3,
      loop: true,
      margin: 10,
      speed: 500,
      rtl: true,

      responsiveClass: true,

      responsive:{

        0:{
          items: 1,
          autoplay: true,
          loop: true,
          margin: 10,
        },
        350:{
          items: 1,
          autoplay: true,
          loop: true,
          margin: 10,
        },
        750:{
          items:3,
          autoplay: true,
          loop:true,
          margin:10,
        }

      }

    });
    AOS.init();

  });
$(document).ready(function(){
     
    $(".slick-slider").slick({

    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    loop: true,
    margin: 10,
    speed: 400,

    responsive: [
    {
      breakpoint: 1200,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
      },
    },
    {
      breakpoint: 1008,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
      },
    },
    {
      breakpoint: 800,
      settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
      },
    },
  ],
      
    });

  });
  $(document).ready(function(){

  $('.hide').hide();
  $('.para').hide();
  $('.show').click(function(){

    $('.para').show();
    $('.show').hide();
    $('.hide').show();

  });
  $('.hide').click(function(){

    $('.para').hide();
    $('.show').show();
    $('.hide').hide();

  });

}); 