$(document).ready(function(){

    $(".owl-carousel").owlCarousel({

        autoplay: true,
        loop: true,
        items: 3,
        margin:20,
        autoplayspeed: 10000,

        responsiveClass:true,

        responsive:{
             0:{
                 autoplay: true,
                 loop: true,
                 items: 1,
              },
             350:{
 
                 autoplay: true,
                 loop: true,
                 items: 1,
             },
             750:{
 
                 autoplay: true,
                 loop: true,
                 items: 3,
             },
        }
    });
});